<?php
$con=mysqli_connect("localhost", "id20584828_lavielroot", "JasonC.Dungca12", "id20584828_lavieldb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
