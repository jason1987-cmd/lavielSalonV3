<?php
include('includes/dbconnection.php');
session_start();
error_reporting(0);

if (isset($_POST['sub'])) {

    $email = $_POST['email'];

    // Check if email is not empty
    if (!empty($email)) {
        // Validate email format
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Perform database insertion
            $query = mysqli_query($con, "INSERT INTO tblsubscriber (Email) VALUES ('$email')");

            // Check if insertion was successful
            if ($query) {
                echo "<script>alert('You subscribed successfully!');</script>";
                echo "<script>window.location.href = 'index.php'</script>";
            } else {
                echo '<script>alert("Something went wrong. Please try again.")</script>';
            }
        } else {
            echo '<script>alert("Invalid email format. Please try again.")</script>';
        }
    } else {
        echo '<script>alert("Email is required. Please try again.")</script>';
    }

}
?>
</br>
<div class="footer">
    <!-- footer-->
    <div class="container">
        <div class="footer-block">
            <!-- footer block -->
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-widget">
                        <h2 class="widget-title">SALON INFO</h2>
                        <ul class="listnone contact">
                            <li><i class="fa fa-map-marker"></i> C&S Building, Tarlac 2300 </li>
                            <li><i class="fa fa-phone"></i> +63 (915) 551-7080</li>
                            <li><i class="fa fa-calendar"></i> 08:00 am to 05:00 pm</li>
                            <li><i class="fa fa-envelope-o"></i> lavielsalon@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-widget footer-social">
                        <!-- social block -->
                        <h2 class="widget-title">Social Feed</h2>
                        <ul class="listnone">
                            <li>
                                <a href="#"> <i class="fa fa-facebook"></i> Facebook </a>
                            </li>
                            <li><a href="#"><i class="fa fa-twitter"></i> Twitter</a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i> Instagram</a></li>
                            <li>
                                <a href="#"> <i class="fa fa-youtube"></i>Youtube</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.social block -->
                </div>
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <div class="footer-widget widget-newsletter">
                        <!-- newsletter block -->
                        <h2 class="widget-title">Subcription Box</h2>
                        <p>Enter your email address to receive a coupon and or discount right to your inbox for new
                            customers and great benefits for old customers.</p>
                        <form method="post">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Enter your email address"
                                    name="email">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="submit" value="submit"
                                        name="sub">Subscribe</button>
                                </span>
                            </div>
                        </form>
                        <!-- /input-group -->
                    </div>
                    <!-- newsletter block -->
                </div>
            </div>
            <div class="tiny-footer">
                <!-- tiny footer block -->
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="copyright-content">
                            <p>© Laviel Salon 2023 | All Rights Resereved</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.tiny footer block -->
        </div>
        <!-- /.footer block -->
    </div>
</div>