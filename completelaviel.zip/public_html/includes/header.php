<div class="header">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/header1.css" rel="stylesheet">

<style>    
img[alt*="000webhost"],
img[alt*="000webhost"][style],
img[src*="000webhost"],
img[src*="000webhost"][style],
body > div:nth-last-of-type(1)[style]{
	opacity: 0 !important;
	pointer-events:none !important;
	width: 0px !important;
	height: 0px !important;
	visibility:hidden !important;
	display:none !important;
}
</style>
<!--for header-->
<style>
        body {
            background-color: #FFBF9B;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        
</style>
    
        <nav class="container">
            <div class="navbar">
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <a class="navbar-brand" href="service-list.php"  style="display: block; text-align: center;">
                        <img src="images/logo.png" alt="" style="max-width: 100%; height: auto;"></a>
                </div>
                <!--
                <div class="col-lg-8 col-md-4 col-sm-12 col-xs-12">
                    <div class="navigations">
                        <div id="navigations">
                            <ul>
                                <li class="active"><a href="index.php" title="Home">Home</a></li>
                                <li><a href="service-list.php" title="Service List">Services</a></li>
                                <li><a href="appointment.php" title="Styleguide">Book Appointment</a> </li>
                            </ul>
                        </div>
                    </div>
                    -->
                </div>
            </div>
        </div>
    </div>
    </nav>
    
    

    