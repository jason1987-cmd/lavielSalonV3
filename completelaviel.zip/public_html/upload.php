<?php
// Connection to MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "lavieldb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form submitted
if (isset($_POST['submit'])) {
    $image = $_FILES['image']['name'];
    $tempName = $_FILES['image']['tmp_name'];
    
    // Upload file to server
    $targetPath = "uploads/" . $image; // Change "uploads/" to the folder where you want to store the uploaded image
    move_uploaded_file($tempName, $targetPath);

    // Insert image file name into MySQL database
    $sql = "INSERT INTO tblappointment (Image) VALUES ('$image')";
    if ($conn->query($sql) === TRUE) {
        echo "Image uploaded successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<body>
  <div class="container mt-5">
    <h1>Image Upload</h1>
    <form action="upload.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="image">Choose Image:</label>
        <input type="file" name="image" id="image" class="form-control-file">
      </div>
      <input type="submit" name="submit" value="Upload" class="btn btn-primary">
    </form>
  </div>
</body>
</html>



